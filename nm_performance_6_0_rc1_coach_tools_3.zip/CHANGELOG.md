# ÑM Performance 6.0 RC1 — Changelog

## Coach Tools 3.0
- Ícono visible de atletas en el menú lateral.
- Nadador B migrado de morado a azul deportivo.
- Comparador con diferencia de Performance Score.
- Tarjetas alineadas, con distintivo de líder y score ring.
- Radar renovado en turquesa y azul.
- Barras de Performance Score.
- Fortalezas automáticas por atleta.
- Enfrentamiento cara a cara en tarjetas responsivas.
- ADN de rendimiento para cinco indicadores.
- Coach Insight con lectura automática.
- Navegación interna por secciones.
- Correcciones específicas para iPhone y pantallas pequeñas.

## Compatibilidad
- Sin cambios de esquema en la base de datos.
- Sin cambios en las rutas existentes.
