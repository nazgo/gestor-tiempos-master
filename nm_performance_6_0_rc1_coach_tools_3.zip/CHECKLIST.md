# Checklist de despliegue

1. Reemplazar el proyecto por el contenido del ZIP.
2. Confirmar que `/coach-tools` abre sin error.
3. Comparar dos nadadores distintos.
4. Verificar el ícono de Coach Tools en el sidebar.
5. Confirmar que el Nadador B aparece azul.
6. Probar escritorio, modo oscuro y teléfono.
7. Confirmar que no existe desplazamiento horizontal en móvil.
